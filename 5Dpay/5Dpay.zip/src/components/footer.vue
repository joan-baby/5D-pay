<template>
  <div id="app">
    footer
  </div>
</template>

<script>

export default {
  name: 'footer',
  components: {
  }
}
</script>

<style>
</style>
