<template>
  <div id="app">
    personal
  </div>
</template>

<script>

export default {
  name: 'personal',
  components: {
  }
}
</script>

<style>
</style>
