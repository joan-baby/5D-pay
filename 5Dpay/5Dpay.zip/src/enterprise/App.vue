<template>
  <div id="app">
    enterprise
  </div>
</template>
<script>
export default {
  name: 'enterprise',
  components: {
  }
}
</script>
<style>
</style>
